# Eugenia Homework Workspace

A React homework and revision platform for English study, organized into:

- Grammar
- Vocabulary
- Reading
- Listening
- Final Quiz

The app stores progress and mistake review data locally in the learner's browser.

## Local development

```bash
npm install
npm run dev
```

## GitHub Pages

This project is configured for a repository named `eugenia-homework` and the Vite base path `/eugenia-homework/`.

After the repository is created and the files are pushed to `main`:

1. Open **Settings → Pages** in the GitHub repository.
2. Under **Build and deployment → Source**, select **GitHub Actions**.
3. The included workflow will build and deploy the app automatically after each push to `main`.

Expected public URL for the `Savascantest` GitHub account:

`https://savascantest.github.io/eugenia-homework/`
