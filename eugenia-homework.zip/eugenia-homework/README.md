# Eugenia Homework Workspace

Interactive English homework and revision platform for Eugenia.

## Homework history

The app now keeps dated homework sets instead of replacing old work.

- **Homework 2 · 21 August 2026** opens by default and is marked **Latest**.
- **Homework 1 · 18 August 2026** remains available from the homework switcher.

Homework 2 is based on the Aug 21 lesson and focuses on:

- Present Simple + Present Continuous for routines vs temporary exceptions
- BE as a state vs BE + verb-ing as Present Continuous
- negative and question formation with auxiliary verbs
- always + Present Continuous for repeated irritating behaviour
- be upset vs get upset vs get/be getting upset
- adjective vs action uses such as "She is annoying" / "She is annoying me"
- stative verbs such as understand
- think vs be thinking
- -ing forms used as noun-like forms ("Reading is fun", "I like working")
- have / have got
- rarely / hardly ever and other tense clues

Progress is stored locally in the student's browser and is separated by homework date.

## Development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
```

The Vite base path is `/eugenia-homework/` for GitHub Pages.
